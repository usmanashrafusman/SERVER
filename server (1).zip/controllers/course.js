import { Router } from "express";
import { body, validationResult } from "express-validator";
import Auth from "../models/auth.js";
import Course from "../models/course.js";
import Form from "../models/form.js";
import { tokenExtractor } from "../utils/authHelpers.js";
import {
  badRequest,
  notFound,
  sendResponse,
  serverError,
} from "../utils/serverResponse.js";

const router = Router();

// ROUTE : 1 POST ADD COURSE
router.post(
  "/addCourse",
  tokenExtractor,
  [
    //validation
    body("courseTitle", "Course Title is requrired").notEmpty(),
    body("duration", "Duration must be in numbers(In Month)").isNumeric(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty) {
      return badRequest(res, { error: errors.array() });
    }
    try {
      const {
        body: { title, duration },
        user,
      } = req;
      let course = await Course.findOne({ title });
      if (course) {
        return badRequest(res, { error: "Name already assigned to a course" });
      }
      course = await Course.create({
        title,
        duration,
        admin: user.id,
      });
      sendResponse(res, 201, { data: course });
    } catch (error) {
      return serverError(error, res);
    }
  }
);

// ROUTE : 2 Get Courses
router.get("/getCourses", async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty) {
    return badRequest(res, { error: errors.array() });
  }
  try {
    const courses = await Course.find();
    sendResponse(res, 200, { courses });
  } catch (error) {
    return serverError(error, res);
  }
});

// ROUTE : 3 Apply in course
router.post("/applyCourse/:courseId", tokenExtractor, async (req, res) => {
  try {
    const {
      name,
      city,
      fatherName,
      email,
      phone,
      cnic,
      fatherCnic,
      dob,
      gender,
      address,
      lastQualification,
      image,
    } = req.body;
    const { courseId } = req.params;
    const { user } = req;
    if (req.isAdmin) {
      return badRequest(res, { error: "Admin can not  apply" });
    }
    let course = await Course.findById(courseId);
    let student = await Auth.findById(user.id);
    if (!student) {
      return badRequest(res, { error: "Student Not Found" });
    }
    let alreadyAppliedStudent = await Auth.findOne({
      appliedCourses: { $in: courseId },
    });
    if (!!alreadyAppliedStudent) {
      return badRequest(res, { error: "Already applied in course" });
    }
    let alreadyAppliedCourse = await Course.findOne({
      appliedStudents: { $in: user.id },
    });
    if (!!alreadyAppliedCourse) {
      return badRequest(res, { error: "Already applied in course" });
    }
    if (!course) {
      return badRequest(res, { error: "Course Not Found" });
    }

    const form = await Form.create({
      city,
      fatherName,
      email,
      phone,
      cnic,
      fatherCnic,
      dob,
      gender,
      address,
      lastQualification,
      image,
      name,
      course: courseId,
    });

    // updating student applied courses
    student.appliedCourses.addToSet(courseId);
    student.save();

    // udpating course
    course.appliedStudents.addToSet(student.id);
    course.save();

    sendResponse(res, 201, { form });
  } catch (error) {
    return serverError(error, res);
  }
});

// ROUTE : 4 update course status
router.get("/updateCourse/:courseId", async (req, res) => {
  try {
    const { courseId } = req.params;
    let course = await Course.findById(courseId);
    if (!course) {
      return notFound(res, { error: "Course not found" });
    }
    // updating status of course admission status
    course.isOpen = false;
    course.save();
    sendResponse(res, 201, { course });
  } catch (error) {
    return serverError(error, res);
  }
});

export default router;
