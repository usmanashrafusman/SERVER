import mongoose from "mongoose";
import dotenv from "dotenv";

// dot env parser
const dotCon = dotenv.config({ path: "configure.env" });

const { DB_USERNAME, DB_CLUSTER, DB_PASSWORD, DB_DATABASE } = process.env;
// const dbUri =
//   "mongodb+srv://AbdullahMotiWala:Bluebirds123@cluster0.docnu.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
const dbUri = "mongodb://127.0.0.1:27017/myDB"

export const dbConnector = () => {
  mongoose.connect(dbUri, () => {
    console.log("Data base conneced Successfully");
  });
};
