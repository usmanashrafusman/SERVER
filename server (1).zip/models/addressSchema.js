import mongoose from "mongoose";

const addressSchema = new mongoose.Schema({
  country: { type: String },
  states: [{ name: { type: String }, cities: [] }],
});

const Country = mongoose.model("country", addressSchema);

// Auth.createIndexes();
export default Country;
